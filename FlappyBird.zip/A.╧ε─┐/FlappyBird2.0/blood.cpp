//=========================�Ŀ����=========================//
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <conio.h>	    //�������� _getch()
#include <string.h>		
#include <time.h>		//�����srand��������
#include <graphics.h>	//ͼ�ο��ļ�
#include <mmsystem.h>	//���ֲ���
#include "function.h"   //�����Զ���ͷ�ļ�
#include "mysql.h"
#include "IMAGE.h"
#include "StructAndGlobal.h"
#pragma comment(lib,"winmm.lib")
#pragma comment(lib,"libmysql.lib")


//=========================��������========================//

//������ֵ
void drawBlood()
{
	switch (heartStruct.numberHearts)
	{
	case 2:
		switch (heartStruct.nowblood)
		{
		case 0:
			putimage(0, 0, 75, 35, hearts + 1, 0, 3, SRCAND);	//2,0
			putimage(0, 0, 75, 35, hearts + 0, 0, 3, SRCPAINT);
			break;
		case 1:

			putimage(0, 0, 75, 35, hearts + 1, 0, 39, SRCAND);	//2,1
			putimage(0, 0, 75, 35, hearts + 0, 0, 39, SRCPAINT);
			break;
		case 2:
			putimage(0, 0, 75, 35, hearts + 1, 0, 78, SRCAND);	//2,2
			putimage(0, 0, 75, 35, hearts + 0, 0, 78, SRCPAINT);

			break;
			
		}
		break;
	case 3:
		switch (heartStruct.nowblood)
		{
		case 0:
			putimage(0, 0, 112, 35, hearts + 1, 0, 118, SRCAND);	//3,0
			putimage(0, 0, 112, 35, hearts + 0, 0, 118, SRCPAINT);

			break;
		case 1:
			putimage(0, 0, 112, 35, hearts + 1, 0, 159, SRCAND);	//3,1
			putimage(0, 0, 112, 35, hearts + 0, 0, 159, SRCPAINT);

			break;
		case 2:

			putimage(0, 0, 112, 35, hearts + 1, 0, 198, SRCAND);	//3,2
			putimage(0, 0, 112, 35, hearts + 0, 0, 198, SRCPAINT);
			break;
		case 3:
			putimage(0, 0, 112, 35, hearts + 1, 0, 235, SRCAND);	//3,3
			putimage(0, 0, 112, 35, hearts + 0, 0, 235, SRCPAINT);
			break;

		}
		break;
	}
	


	
	//======================



	

}