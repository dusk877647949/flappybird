//=========================�Ŀ����=========================//
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <conio.h>	    //�������� _getch()
#include <string.h>		
#include <time.h>		//�����srand��������
#include <graphics.h>	//ͼ�ο��ļ�
#include <mmsystem.h>	//���ֲ���
#include "function.h"   //�����Զ���ͷ�ļ�
#include "mysql.h"
#include "IMAGE.h"
#include "StructAndGlobal.h"
#pragma comment(lib,"winmm.lib")
#pragma comment(lib,"libmysql.lib")

//=========================��������========================//

//����
void drawEgg()
{
	switch (eggStruct.color)
	{
	case 1:
		putimage(eggStruct.x, eggStruct.y, 28, 30, eggs + 1, 0, 0, SRCAND);	//1
		putimage(eggStruct.x, eggStruct.y, 28, 30, eggs + 0, 0, 0, SRCPAINT);
		break;
	case 2:
		putimage(eggStruct.x, eggStruct.y, 28, 30, eggs + 1, 34, 0, SRCAND);	//2
		putimage(eggStruct.x, eggStruct.y, 28, 30, eggs + 0, 34, 0, SRCPAINT);

		break;
	case 3:
		putimage(eggStruct.x, eggStruct.y, 28, 30, eggs + 1, 69, 0, SRCAND);	//3
		putimage(eggStruct.x, eggStruct.y, 28, 30, eggs + 0, 69, 0, SRCPAINT);
		break;
	case 4:
		putimage(eggStruct.x, eggStruct.y, 28, 30, eggs + 1, 102, 0, SRCAND);	//4
		putimage(eggStruct.x, eggStruct.y, 28, 30, eggs + 0, 102, 0, SRCPAINT);
		break;
	}
	if ( eggStruct.color < 4)	//�ı���ɫ
	{
		eggStruct.color++;
	}
	else
	{
		eggStruct.color = 1;
	}
	
}
