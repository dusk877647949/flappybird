//=========================�Ŀ����=========================//
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <conio.h>	    //�������� _getch()
#include <string.h>		
#include <time.h>		//�����srand��������
#include <graphics.h>	//ͼ�ο��ļ�
#include <mmsystem.h>	//���ֲ���
#include "function.h"   //�����Զ���ͷ�ļ�
#include "mysql.h"
#include "IMAGE.h"
#include "StructAndGlobal.h"
#pragma comment(lib,"winmm.lib")
#pragma comment(lib,"libmysql.lib")

//=========================��������========================//


//����ɫ�Ĺ���
void drawMonster()
{
	switch (monsterStruct.direction)
	{
	case 'a':

		switch (monsterStruct.shape)
		{
		case 0:
			putimage(monsterStruct.x, monsterStruct.y, 32, 32, game3 + 1, 134, 351, SRCAND);	//����
			putimage(monsterStruct.x, monsterStruct.y, 32, 32, game3 + 0, 134, 351, SRCPAINT);
			break;
		case 1:
			putimage(monsterStruct.x, monsterStruct.y, 32, 32, game3 + 1, 173, 351, SRCAND);	//����
			putimage(monsterStruct.x, monsterStruct.y, 32, 32, game3 + 0, 173, 351, SRCPAINT);
			break;
		case 2:
			putimage(monsterStruct.x, monsterStruct.y, 32, 32, game3 + 1, 214, 351, SRCAND);	//����
			putimage(monsterStruct.x, monsterStruct.y, 32, 32, game3 + 0, 214, 351, SRCPAINT);
			break;
		case 3:
			putimage(monsterStruct.x, monsterStruct.y, 32, 32, game3 + 1, 254, 351, SRCAND);	//����
			putimage(monsterStruct.x, monsterStruct.y, 32, 32, game3 + 0, 254, 351, SRCPAINT);
			break;

		}
		break;
	case 'd':
		switch (monsterStruct.shape)
		{
		case 0:
			putimage(monsterStruct.x, monsterStruct.y, 32, 32, game4 + 1, 349, 351, SRCAND);	//����
			putimage(monsterStruct.x, monsterStruct.y, 32, 32, game4 + 0, 349, 351, SRCPAINT);
			break;
		case 1:
			putimage(monsterStruct.x, monsterStruct.y, 32, 32, game4 + 1, 389, 351, SRCAND);	//����
			putimage(monsterStruct.x, monsterStruct.y, 32, 32, game4 + 0, 389, 351, SRCPAINT);
			break;
		case 2:
			putimage(monsterStruct.x, monsterStruct.y, 32, 32, game4 + 1, 428, 351, SRCAND);	//����
			putimage(monsterStruct.x, monsterStruct.y, 32, 32, game4 + 0, 428, 351, SRCPAINT);
			break;
		case 3:
			putimage(monsterStruct.x, monsterStruct.y, 32, 32, game4 + 1, 469, 351, SRCAND);	//����
			putimage(monsterStruct.x, monsterStruct.y, 32, 32, game4 + 0, 469, 351, SRCPAINT);
			break;

		}
		break;
	}

	monsterStruct.shape++;
	if (monsterStruct.shape == 4)
	{
		monsterStruct.shape = 0;
	}
	

}

//�ж�ײ������
int hitMonster()
{
	if (monsterStruct.key == 1)
	{
		if (((monsterStruct.x <= flayBird.x  && flayBird.x <= monsterStruct.x + 32) ||
			(monsterStruct.x <= flayBird.x + 34 && flayBird.x + 34 <= monsterStruct.x + 32)) &&
			((monsterStruct.y  <= flayBird.y && flayBird.y <= monsterStruct.y  + 32) ||
			(monsterStruct.y  <= flayBird.y + 24 && flayBird.y + 24 <= monsterStruct.y  + 32)))
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	else
	{
		return 0;
	}

}