//=========================�Ŀ����=========================//
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <conio.h>	    //�������� _getch()
#include <string.h>		
#include <time.h>		//�����srand��������
#include <graphics.h>	//ͼ�ο��ļ�
#include <mmsystem.h>	//���ֲ���
#include "function.h"   //�����Զ���ͷ�ļ�
#include "mysql.h"
#include "IMAGE.h"
#include "StructAndGlobal.h"
#pragma comment(lib,"winmm.lib")
#pragma comment(lib,"libmysql.lib")


//=========================��������========================//

//������׹��
void birdFall()
{
	int x = flayBird.x, y = flayBird.y + 34;
	int i = 1;
	int key = 0;
	IMAGE img;	//���汳��ͼ
	getimage(&img, 0, 0, 275, 617);
	BeginBatchDraw();//������ͼ
	while (key==0)
	{
		if (y >= 512 - 100 )
		{
			y = 512 - 34;
			key = 1;
		}
		putimage(0, 0, &img);
		 
		putimage(x, y, 24, 34, fall + 1, 0, 0, SRCAND);	//��ӡ��׹ͼƬ
		putimage(x, y, 24, 34, fall + 0, 0, 0, SRCPAINT);
		if ((i--) == 1)
		{
			CreateThread(NULL, NULL, playMusicDie, NULL, NULL, NULL);//��������
		}

		if ( y < 512 - 34-50)
		{
			y += 50;
		}

		FlushBatchDraw();
		Sleep(100);
	}
	EndBatchDraw();
}

//����������
void  normalFall()
{
	if (flayBird.die != 'y')	//���ж�С���Ƿ�����
	{
		flayBird.y += flayBird.spend*t + int(0.1*G*t*t);    //���Զ�����
		if (flayBird.spend < 0)
		{
			flayBird.spend = flayBird.spend + G * t;
		}
		else if (flayBird.spend > 0)
		{
			flayBird.spend = 0;
		}


		while (_kbhit())  //�а����Ŵ���
		{
			keyDown();
		}
	}

}

//��������,��
void  keyDown()
{
	char userKey = _getch();   //�����û�����

	switch (userKey)
	{
	case 72:
	case ' ':
	{
		flayBird.spend = -7;	//���ϵ��ٶ�
		t = T;
		CreateThread(NULL, NULL, playMusicWing, NULL, NULL, NULL);	//�����Ч
		break;
	}
	case 'z':
	case 'Z':
	{
		//flayBird.keyBullet = 'y';
		if (flayBird.keyBullet != 'n')	//�ж��ܹ������ӵ�
			if (flayBird.bullet[0].fireBullet != 'y')
			{
				flayBird.bullet[0].fireBullet = 'y';
				flayBird.bullet[0].x = flayBird.x + 34;
				flayBird.bullet[0].y = flayBird.y + 4;
				flayBird.bullet[0].rebound = 'n';//	��ʾ�ӵ���������
				CreateThread(NULL, NULL, playMusicFire, NULL, NULL, NULL);	//���������Ч
			}
			else if (flayBird.bullet[1].fireBullet != 'y')
			{
				flayBird.bullet[1].fireBullet = 'y';
				flayBird.bullet[1].x = flayBird.x + 34;
				flayBird.bullet[1].y = flayBird.y + 4;
				flayBird.bullet[1].rebound = 'n';//	��ʾ�ӵ���������
				CreateThread(NULL, NULL, playMusicFire, NULL, NULL, NULL);	//���������Ч
			}
			else if (flayBird.bullet[2].fireBullet != 'y')
			{
				flayBird.bullet[2].fireBullet = 'y';
				flayBird.bullet[2].x = flayBird.x + 34;
				flayBird.bullet[2].y = flayBird.y + 4;
				flayBird.bullet[2].rebound = 'n';//	��ʾ�ӵ���������
				CreateThread(NULL, NULL, playMusicFire, NULL, NULL, NULL);	//���������Ч
			}
			else if (flayBird.bullet[3].fireBullet != 'y')
			{
				flayBird.bullet[3].fireBullet = 'y';
				flayBird.bullet[3].x = flayBird.x + 34;
				flayBird.bullet[3].y = flayBird.y + 4;
				flayBird.bullet[3].rebound = 'n';//	��ʾ�ӵ���������
				CreateThread(NULL, NULL, playMusicFire, NULL, NULL, NULL);	//���������Ч
			}
			else if (flayBird.bullet[4].fireBullet != 'y')
			{
				flayBird.bullet[4].fireBullet = 'y';
				flayBird.bullet[4].x = flayBird.x + 34;
				flayBird.bullet[4].y = flayBird.y + 4;
				flayBird.bullet[4].rebound = 'n';//	��ʾ�ӵ���������
				CreateThread(NULL, NULL, playMusicFire, NULL, NULL, NULL);	//���������Ч
			}


		break;
	}

	default:
		break;
	}
}

//��������
void drawBird(int x, int y)
{

	/*************��ͼ����*********
		 SRCAND		������ͼ
		 SRCPAINT   ������ͼ
	 *****************************/
	static int i = 0;
	if (flayBird.strong > 0)	//���ٰ���ָ��
	{
		if (flayBird.strong % 2 == 0)
		{
			//�������
			if (i % 3 == 0)
			{
				putimage(x, y, 34, 24, bird + 1, 0, 0, SRCAND);   //������ͼ
				putimage(x, y, 34, 24, bird + 0, 0, 0, SRCPAINT); //��Դ��ͼ
			}
			//�������
			else if (i % 3 == 1)
			{
				putimage(x, y, 34, 24, bird + 3, 0, 0, SRCAND);   //������ͼ
				putimage(x, y, 34, 24, bird + 2, 0, 0, SRCPAINT); //��Դ��ͼ
			}
			//�������
			else if (i % 3 == 2)
			{
				putimage(x, y, 34, 24, bird + 5, 0, 0, SRCAND);   //������ͼ
				putimage(x, y, 34, 24, bird + 4, 0, 0, SRCPAINT); //��Դ��ͼ
			}
		}
		flayBird.strong--;
	}
	else
	{
		//�������
		if (i % 3 == 0)
		{
			putimage(x, y, 34, 24, bird + 1, 0, 0, SRCAND);   //������ͼ
			putimage(x, y, 34, 24, bird + 0, 0, 0, SRCPAINT); //��Դ��ͼ
		}
		//�������
		else if (i % 3 == 1)
		{
			putimage(x, y, 34, 24, bird + 3, 0, 0, SRCAND);   //������ͼ
			putimage(x, y, 34, 24, bird + 2, 0, 0, SRCPAINT); //��Դ��ͼ
		}
		//�������
		else if (i % 3 == 2)
		{
			putimage(x, y, 34, 24, bird + 5, 0, 0, SRCAND);   //������ͼ
			putimage(x, y, 34, 24, bird + 4, 0, 0, SRCPAINT); //��Դ��ͼ
		}
	}

	i++;
	if (i == 3)
	{
		i = 0;
	}

}

//����ײ������
int hitPillar(struct pillar Array[3], int code)
{
	int i = 0;
	//ѡ�ж��Ƿ����boss 
	if (BossButton != 'y' || (Array[0].x >= (-52 - 272) || Array[1].x >= (-52 - 272) || Array[2].x >= (-52 - 272)))
	{
		switch (code)
		{
		case 0:	return 0;//��Ϸ����

		case 1:if (flayBird.y <= Array[i].height || flayBird.y + 24 >= 512 - (320 - Array[i].height))//�ж����Ƿ���ײ���·�����
		{
			return 1;//��Ϸʧ��
		}break;

		case 2:if (flayBird.y <= Array[i + 1].height || flayBird.y + 24 >= 512 - (320 - Array[i + 1].height))//�ж����Ƿ���ײ���·�����
		{
			return 1;//��Ϸʧ��
		}break;

		case 3:if (flayBird.y <= Array[i + 2].height || flayBird.y + 24 >= 512 - (320 - Array[i + 2].height))//�ж����Ƿ���ײ�Ϸ�����
		{
			return 1;//��Ϸʧ��
		}break;
		}
	}

	return 0;
}

//�ж����Ƿ�Ҫײ������
int choosePillar(struct pillar Array[3])
{
	int i = 0;
	if (Array[i].x <= flayBird.x + 34 && Array[i].x + 52 >= flayBird.x)
	{
		return 1;//�жϳɹ�
	}
	else if (Array[i + 1].x <= flayBird.x + 34 && Array[i + 1].x + 52 >= flayBird.x)
	{
		return 2;//�жϳɹ�
	}
	else if (Array[i + 2].x <= flayBird.x + 34 && Array[i + 2].x + 52 >= flayBird.x)
	{
		return 3;//�жϳɹ�
	}
	else
	{
		return 0;
	}
}

//����ײ���ذ�
int hitFloor()
{
	if (flayBird.y+24 > (617 - 105) || flayBird.y <= 0)
	{
		return 1;//��Ϸʧ��
	}
	else
	{
		return 0;
	}
}

//���ӵ�
void drawBullet()
{
	for (int i = 0; i <= 4; i++)
	{
		if (flayBird.bullet[i].fireBullet != 'n'&&flayBird.bullet[i].rebound == 'n')
		{
			//�ӵ�����
			putimage(flayBird.bullet[i].x, flayBird.bullet[i].y, 16, 16, game1 + 1, 363, 226, SRCAND);   //������ͼ
			putimage(flayBird.bullet[i].x, flayBird.bullet[i].y, 16, 16, game1 + 0, 363, 226, SRCPAINT); //��Դ��ͼ
			flayBird.bullet[i].x += 10;
			if (flayBird.bullet[i].x >= 275)	//�ӵ��Ƿ񵽴��ֱ߽�
			{
				flayBird.bullet[i].x = 275;
				flayBird.bullet[i].fireBullet = 'n';	//��ʾ���Է���
			}


		}
		else if (flayBird.bullet[i].fireBullet != 'n'&&flayBird.bullet[i].rebound == 'y')
		{

			//�ӵ�����
			putimage(flayBird.bullet[i].x, flayBird.bullet[i].y, 16, 16, game1 + 1, 363, 202, SRCAND);   //������ͼ
			putimage(flayBird.bullet[i].x, flayBird.bullet[i].y, 16, 16, game1 + 0, 363, 202, SRCPAINT); //��Դ��ͼ
			flayBird.bullet[i].x -= 20;
			flayBird.bullet[i].y += 10;
			if (flayBird.bullet[i].x <= -16)	//�ӵ��Ƿ񵽴��ֱ߽�
			{
				flayBird.bullet[i].x = 275;	//��ֹһֱ�ƶ�
				flayBird.bullet[i].fireBullet = 'n';	//��ʾ���Է���
			}
			else if (flayBird.bullet[i].y >= 613 || flayBird.bullet[i].y <= -16)
			{
				flayBird.bullet[i].x = 275;	//��ֹһֱ�ƶ�
				flayBird.bullet[i].fireBullet = 'n';	//��ʾ���Է���
			}
		}

	}

}

//�ж��Ƿ��ӵ�ײ��boss
int hitBirdBoss()
{
	for (int i = 0; i <= 4; i++)
	{
		if (flayBird.bullet[i].fireBullet != 'n'&&bossStruct.die != 'y'&& BossButton == 'y')
		{

			//���ж�boss�Ƿ�Ϊ�޵�״̬
			if (bossStruct.elude == 'y' && ((flayBird.bullet[i].x + 16 >= bossStruct.x&& flayBird.bullet[i].x <= bossStruct.x + 30)
				&& (flayBird.bullet[i].y <= bossStruct.y + 57 && flayBird.bullet[i].y + 16 >= bossStruct.y + 21)))
			{
				flayBird.bullet[i].rebound = 'y';//	��ʾ�ӵ�������
				CreateThread(NULL, NULL, playMusicRebound, NULL, NULL, NULL);//�ӵ���������
				return 0;
			}
			else if ((flayBird.bullet[i].x + 16 >= bossStruct.x&& flayBird.bullet[i].x <= bossStruct.x + 30)
				&& (flayBird.bullet[i].y <= bossStruct.y + 57 && flayBird.bullet[i].y + 16 >= bossStruct.y))
			{
				flayBird.bullet[i].fireBullet = 'n';	//�ӵ���ʧ
				bossStruct.blood--;	//bossѪ������
				action3 = i + 1;	//��ȡ���ָ��
				return 1;
			}

		}
	}
	return 0;
}

//�ж��Ƿ�ײ����ͨ�ĵ���
void hitCommonEnemy()
{
	for (int i = 0; i <= 4; i++)
	{
		if (flayBird.bullet[i].fireBullet != 'n')	//���ж��ӵ��Ƿ���
		{
			//�ж�ײ�����
			if (swanStruct.key == 1 && swanStruct.x != 275)
			{
				switch (swanStruct.shape)	//���������״�ж�
				{
				case 0:
					if (((swanStruct.x <= flayBird.bullet[i].x  && flayBird.bullet[i].x <= swanStruct.x + 42) ||
						(swanStruct.x <= flayBird.bullet[i].x + 16 && flayBird.bullet[i].x + 16 <= swanStruct.x + 42)) &&
						((swanStruct.y <= flayBird.bullet[i].y && flayBird.bullet[i].y <= swanStruct.y + 37) ||
						(swanStruct.y <= flayBird.bullet[i].y + 16 && flayBird.bullet[i].y + 16 <= swanStruct.y + 37)))
					{
						flayBird.bullet[i].fireBullet = 'n';
						swanStruct.blood--;
						if (swanStruct.blood == 0)
						{
							//drawDie();	//��������
							dieStruct = { swanStruct.x, swanStruct.y ,1,0 };
							swanStruct.die = 'y';
							swanStruct.key = 0;
						}
						continue;
					}
					break;
				case 1:
					if (((swanStruct.x <= flayBird.bullet[i].x  && flayBird.bullet[i].x <= swanStruct.x + 46) ||
						(swanStruct.x <= flayBird.bullet[i].x + 16 && flayBird.bullet[i].x + 16 <= swanStruct.x + 46)) &&
						((swanStruct.y <= flayBird.bullet[i].y && flayBird.bullet[i].y <= swanStruct.y + 25) ||
						(swanStruct.y <= flayBird.bullet[i].y + 16 && flayBird.bullet[i].y + 16 <= swanStruct.y + 25)))
					{
						flayBird.bullet[i].fireBullet = 'n';	//�ӵ���ʾΪ�ɷ���״̬
						swanStruct.blood--;	//��Ѫ
						if (swanStruct.blood == 0)	//�ж��Ƿ�����
						{

							//drawDie(swanStruct.x, swanStruct.y);	//��������
							dieStruct = { swanStruct.x, swanStruct.y ,1,0 };
							swanStruct.die = 'y';
							swanStruct.key = 0;
						}
						continue;
					}

					break;
				}
			}
			//�ж�ײ����
			if (eggStruct.key != 'n'&&eggStruct.x != 275)
			{
				if (((eggStruct.x <= flayBird.bullet[i].x  && flayBird.bullet[i].x <= eggStruct.x + 28) ||
					(eggStruct.x <= flayBird.bullet[i].x + 16 && flayBird.bullet[i].x + 16 <= eggStruct.x + 28)) &&
					((eggStruct.y <= flayBird.bullet[i].y && flayBird.bullet[i].y <= eggStruct.y + 32) ||
					(eggStruct.y <= flayBird.bullet[i].y + 16 && flayBird.bullet[i].y + 16 <= eggStruct.y + 32)))
				{
					flayBird.bullet[i].fireBullet = 'n';
					eggStruct.blood--;
					if (eggStruct.blood == 0)
					{
						//drawDie(eggStruct.x, eggStruct.y);	//��������
						dieStruct = { eggStruct.x, eggStruct.y ,1,0 };
						eggStruct = { 275,270,'n',1,'s',2 }; //���ṹ��
						eggStruct.key = 0;
						heartStruct.numberHearts = 3;	//Ѫ����������
						CreateThread(NULL, NULL, playMusicEgg, NULL, NULL, NULL);//С���Ѫ����
					}
					continue;
				}



			}
			//�ж�ײ������
			if (missileStruct.key == 1 && missileStruct.x != 275)
			{

				if (((missileStruct.x <= flayBird.bullet[i].x  && flayBird.bullet[i].x <= missileStruct.x + 30) ||
					(missileStruct.x <= flayBird.bullet[i].x + 16 && flayBird.bullet[i].x + 16 <= missileStruct.x + 30)) &&
					((missileStruct.y <= flayBird.bullet[i].y && flayBird.bullet[i].y <= missileStruct.y + 26) ||
					(missileStruct.y <= flayBird.bullet[i].y + 16 && flayBird.bullet[i].y + 16 <= missileStruct.y + 26)))
				{
					flayBird.bullet[i].fireBullet = 'n';
					//drawDie(missileStruct.x, missileStruct.y);	//��������
					dieStruct = { missileStruct.x, missileStruct.y ,1,0 };
					missileStruct = { 275,200,0,1,15,'n',0 }; //�����ṹ�壬���³�ʼ��

					continue;

				}

			}
			//�ж�ײ��С��
			if (ghostStruct.key == 1 && ghostStruct.x != 275)
			{

				if (((ghostStruct.x <= flayBird.bullet[i].x  && flayBird.bullet[i].x <= ghostStruct.x + 33) ||
					(ghostStruct.x <= flayBird.bullet[i].x + 16 && flayBird.bullet[i].x + 16 <= ghostStruct.x + 33)) &&
					((ghostStruct.y <= flayBird.bullet[i].y && flayBird.bullet[i].y <= ghostStruct.y + 32) ||
					(ghostStruct.y <= flayBird.bullet[i].y + 16 && flayBird.bullet[i].y + 16 <= ghostStruct.y + 32)))
				{
					flayBird.bullet[i].fireBullet = 'n';
					ghostStruct.blood--;
					if (ghostStruct.blood == 0)	//�ж�Ѫ���Ƿ�Ϊ0
					{
						//drawDie(ghostStruct.x, ghostStruct.y);	//��������
						dieStruct = { ghostStruct.x, ghostStruct.y ,1,0 };
						ghostStruct = { 275,50,0,15,'n',0 ,2 }; //С���ṹ��
						
					}
					continue;
				}

			}
			//�ж�ײ��С����
			if (goblinStruct.key == 1 && goblinStruct.x != 275)
			{

				if (((goblinStruct.x <= flayBird.bullet[i].x  && flayBird.bullet[i].x <= goblinStruct.x + 16) ||
					(goblinStruct.x <= flayBird.bullet[i].x + 16 && flayBird.bullet[i].x + 16 <= goblinStruct.x + 16)) &&
					((goblinStruct.y <= flayBird.bullet[i].y && flayBird.bullet[i].y <= goblinStruct.y + 27) ||
					(goblinStruct.y <= flayBird.bullet[i].y + 16 && flayBird.bullet[i].y + 16 <= goblinStruct.y + 27)))
				{
					flayBird.bullet[i].fireBullet = 'n';
					//drawDie(goblinStruct.x, goblinStruct.y);	//��������
					dieStruct = { goblinStruct.x, goblinStruct.y ,1,0 };
					goblinStruct = { 275,200,0,0,5 ,0 }; //С����ṹ��
					continue;

				}

			}
			//�ж�ײ���ڹ�
			if (tortoiseStruct.key == 1 && tortoiseStruct.x != 275)
			{
				switch (tortoiseStruct.shape)//������״�ж�ײ���¼�
				{
				case 0:
					if (((tortoiseStruct.x <= flayBird.bullet[i].x  && flayBird.bullet[i].x <= tortoiseStruct.x + 33) ||
						(tortoiseStruct.x <= flayBird.bullet[i].x + 16 && flayBird.bullet[i].x + 16 <= tortoiseStruct.x + 33)) &&
						((tortoiseStruct.y - 9 <= flayBird.bullet[i].y && flayBird.bullet[i].y <= tortoiseStruct.y - 9 + 40) ||
						(tortoiseStruct.y - 9 <= flayBird.bullet[i].y + 16 && flayBird.bullet[i].y + 16 <= tortoiseStruct.y - 9 + 40)))
					{
						flayBird.bullet[i].fireBullet = 'n';
						tortoiseStruct.blood--;
						if (tortoiseStruct.blood== 0)
						{
							//drawDie(tortoiseStruct.x, tortoiseStruct.y);	//��������
							dieStruct = { tortoiseStruct.x, tortoiseStruct.y ,1,0 };
							tortoiseStruct = { 275,200,0,0,7,0,4 };	//�ڹ�ṹ��
							
						}
						continue;
					}

					break;
				case 1:
					if (((tortoiseStruct.x <= flayBird.bullet[i].x  && flayBird.bullet[i].x <= tortoiseStruct.x + 31) ||
						(tortoiseStruct.x <= flayBird.bullet[i].x + 16 && flayBird.bullet[i].x + 16 <= tortoiseStruct.x + 31)) &&
						((tortoiseStruct.y <= flayBird.bullet[i].y && flayBird.bullet[i].y <= tortoiseStruct.y + 31) ||
						(tortoiseStruct.y <= flayBird.bullet[i].y + 16 && flayBird.bullet[i].y + 16 <= tortoiseStruct.y + 31)))
					{
						flayBird.bullet[i].fireBullet = 'n';
						tortoiseStruct.blood--;
						if (tortoiseStruct.blood == 0)
						{
							//drawDie(tortoiseStruct.x, tortoiseStruct.y);	//��������
							dieStruct = { tortoiseStruct.x, tortoiseStruct.y ,1,0 };
							tortoiseStruct = { 275,200,0,0,7,0,4 };	//�ڹ�ṹ��

						}
						continue;
					}

					break;
				case 2:
					if (((tortoiseStruct.x <= flayBird.bullet[i].x  && flayBird.bullet[i].x <= tortoiseStruct.x + 34) ||
						(tortoiseStruct.x <= flayBird.bullet[i].x + 16 && flayBird.bullet[i].x + 16 <= tortoiseStruct.x + 34)) &&
						((tortoiseStruct.y <= flayBird.bullet[i].y && flayBird.bullet[i].y <= tortoiseStruct.y + 39) ||
						(tortoiseStruct.y <= flayBird.bullet[i].y + 16 && flayBird.bullet[i].y + 16 <= tortoiseStruct.y + 39)))
					{
						flayBird.bullet[i].fireBullet = 'n';
						tortoiseStruct.blood--;
						if (tortoiseStruct.blood == 0)
						{
							//drawDie(tortoiseStruct.x, tortoiseStruct.y);	//��������
							dieStruct = { tortoiseStruct.x, tortoiseStruct.y ,1,0 };
							tortoiseStruct = { 275,200,0,0,7,0,4 };	//�ڹ�ṹ��

						}
						continue;
					}

					break;
				case 3:
					if (((tortoiseStruct.x <= flayBird.bullet[i].x  && flayBird.bullet[i].x <= tortoiseStruct.x + 38) ||
						(tortoiseStruct.x <= flayBird.bullet[i].x + 16 && flayBird.bullet[i].x + 16 <= tortoiseStruct.x + 38)) &&
						((tortoiseStruct.y <= flayBird.bullet[i].y && flayBird.bullet[i].y <= tortoiseStruct.y + 31) ||
						(tortoiseStruct.y <= flayBird.bullet[i].y + 16 && flayBird.bullet[i].y + 16 <= tortoiseStruct.y + 31)))
					{
						flayBird.bullet[i].fireBullet = 'n';
						tortoiseStruct.blood--;
						if (tortoiseStruct.blood == 0)
						{
							//drawDie(tortoiseStruct.x, tortoiseStruct.y);	//��������
							dieStruct = { tortoiseStruct.x, tortoiseStruct.y ,1,0 };
							tortoiseStruct = { 275,200,0,0,7,0,4 };	//�ڹ�ṹ��

						}
						continue;
					}

					break;
				case 4:
					if (((tortoiseStruct.x <= flayBird.bullet[i].x  && flayBird.bullet[i].x <= tortoiseStruct.x + 38) ||
						(tortoiseStruct.x <= flayBird.bullet[i].x + 16 && flayBird.bullet[i].x + 16 <= tortoiseStruct.x + 38)) &&
						((tortoiseStruct.y <= flayBird.bullet[i].y && flayBird.bullet[i].y <= tortoiseStruct.y + 29) ||
						(tortoiseStruct.y <= flayBird.bullet[i].y + 16 && flayBird.bullet[i].y + 16 <= tortoiseStruct.y + 29)))
					{
						flayBird.bullet[i].fireBullet = 'n';
						tortoiseStruct.blood--;
						if (tortoiseStruct.blood == 0)
						{
							//drawDie(tortoiseStruct.x, tortoiseStruct.y);	//��������
							dieStruct = { tortoiseStruct.x, tortoiseStruct.y ,1,0 };
							tortoiseStruct = { 275,200,0,0,7,0,4 };	//�ڹ�ṹ��

						}
						continue;
					}

					break;
				case 5:
					if (((tortoiseStruct.x <= flayBird.bullet[i].x  && flayBird.bullet[i].x <= tortoiseStruct.x + 36) ||
						(tortoiseStruct.x <= flayBird.bullet[i].x + 16 && flayBird.bullet[i].x + 16 <= tortoiseStruct.x + 36)) &&
						((tortoiseStruct.y <= flayBird.bullet[i].y && flayBird.bullet[i].y <= tortoiseStruct.y + 36) ||
						(tortoiseStruct.y <= flayBird.bullet[i].y + 16 && flayBird.bullet[i].y + 16 <= tortoiseStruct.y + 36)))
					{
						flayBird.bullet[i].fireBullet = 'n';
						tortoiseStruct.blood--;
						if (tortoiseStruct.blood == 0)
						{
							//drawDie(tortoiseStruct.x, tortoiseStruct.y);	//��������
							dieStruct = { tortoiseStruct.x, tortoiseStruct.y ,1,0 };
							tortoiseStruct = { 275,200,0,0,7,0,4 };	//�ڹ�ṹ��

						}
						continue;
					}

					break;

				}

			}


		}
	}

}
