//=========================�Ŀ����=========================//
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <conio.h>	    //�������� _getch()
#include <string.h>		
#include <time.h>		//�����srand��������
#include <graphics.h>	//ͼ�ο��ļ�
#include <mmsystem.h>	//���ֲ���
#include "function.h"   //�����Զ���ͷ�ļ�
#include "mysql.h"
#include "IMAGE.h"
#include "StructAndGlobal.h"
#pragma comment(lib,"winmm.lib")
#pragma comment(lib,"libmysql.lib")


//=========================��������========================//

//��С����
void drawGoblin()
{

	switch (goblinStruct.shape)
	{
	case 0:
		putimage(goblinStruct.x, goblinStruct.y, 16, 27, game3 + 1, 431, 99, SRCAND);	//С����
		putimage(goblinStruct.x, goblinStruct.y, 16, 27, game3 + 0, 431, 99, SRCPAINT);
		break;
	case 1:
		putimage(goblinStruct.x, goblinStruct.y, 16, 27, game3 + 1, 451, 99, SRCAND);	//С����
		putimage(goblinStruct.x, goblinStruct.y, 16, 27, game3 + 0, 451, 99, SRCPAINT);
		break;
	case 2:
		putimage(goblinStruct.x, goblinStruct.y, 16, 27, game3 + 1, 471, 99, SRCAND);	//С����
		putimage(goblinStruct.x, goblinStruct.y, 16, 27, game3 + 0, 471, 99, SRCPAINT);
		break;
	case 3:
		putimage(goblinStruct.x, goblinStruct.y, 16, 27, game3 + 1, 491, 99, SRCAND);	//С����
		putimage(goblinStruct.x, goblinStruct.y, 16, 27, game3 + 0, 491, 99, SRCPAINT);
		break;
	}

	goblinStruct.shape++;
	if (goblinStruct.shape == 4)
	{
		goblinStruct.shape = 0;
	}
	
}


//�ж��Ƿ�ײ��С����
int  hitGoblin()
{

	if (   (   (goblinStruct.x <= flayBird.x  && goblinStruct.x + 16 >= flayBird.x)|| 
		(goblinStruct.x <= flayBird.x+34  && goblinStruct.x + 16 >= flayBird.x+34))  &&
		((goblinStruct.y + 32 >= flayBird.y && goblinStruct.y <= flayBird.y ) ||
		(goblinStruct.y + 32 >= flayBird.y+24 && goblinStruct.y <= flayBird.y + 24)) )
	{

		return 1;
	}
	else
	{
		return 0;
	}


}

