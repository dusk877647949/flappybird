//=========================�Ŀ����=========================//
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <conio.h>	    //�������� _getch()
#include <string.h>		
#include <time.h>		//�����srand��������
#include <graphics.h>	//ͼ�ο��ļ�
#include <mmsystem.h>	//���ֲ���
#include "function.h"   //�����Զ���ͷ�ļ�
#include "mysql.h"
#include "IMAGE.h"
#include "StructAndGlobal.h"
#pragma comment(lib,"winmm.lib")
#pragma comment(lib,"libmysql.lib")


//=========================��������========================//

//��ʳ�˻�
void drawFlower(struct Flower flowerArray)
{
	
	switch (flowerArray.direction) 
	{
	case 'w':	//ͷ����
	{
		switch (flowerArray.color)	//�ı���ɫ
		{
		case 0:
			if (flowerArray.shape == 1)	
			{
				putimage(flowerArray.x, flowerArray.y, 30, 25, game1 + 1, 113, 187, SRCAND);	//
				putimage(flowerArray.x, flowerArray.y, 30, 25, game1 + 0, 113, 187, SRCPAINT);

			}
			else
			{
				putimage(flowerArray.x, flowerArray.y, 30, 25, game1 + 1, 113, 217, SRCAND);	//
				putimage(flowerArray.x, flowerArray.y, 30, 25, game1 + 0, 113, 217, SRCPAINT);
			}
			break;
		case 1:
			if (flowerArray.shape == 1)
			{   
				putimage(flowerArray.x, flowerArray.y, 30, 25, game1 + 1, 113, 258, SRCAND);	//
				putimage(flowerArray.x, flowerArray.y, 30, 25, game1 + 0, 113, 258, SRCPAINT);
			}
			else
			{
				putimage(flowerArray.x, flowerArray.y, 30, 25, game1 + 1, 113, 290, SRCAND);	//
				putimage(flowerArray.x, flowerArray.y, 30, 25, game1 + 0, 113, 290, SRCPAINT);
			}
			break;
		case 2:
			if (flowerArray.shape == 1 )
			{
				putimage(flowerArray.x, flowerArray.y, 30, 25, game1 + 1, 113, 326, SRCAND);	//
				putimage(flowerArray.x, flowerArray.y, 30, 25, game1 + 0, 113, 326, SRCPAINT);
			}
			else
			{
				putimage(flowerArray.x, flowerArray.y, 30, 25, game1 + 1, 113, 357, SRCAND);	//
				putimage(flowerArray.x, flowerArray.y, 30, 25, game1 + 0, 113, 357, SRCPAINT);
			}
			break;

		}
	}
		
		break;
	case 's':	//ͷ����
		switch (flowerArray.color)
		{
		case 0:
			if (flowerArray.shape == 0)
			{
				putimage(flowerArray.x, flowerArray.y, 30, 25, game1 + 1, 77, 191, SRCAND);	//
				putimage(flowerArray.x, flowerArray.y, 30, 25, game1 + 0, 77, 191, SRCPAINT);
			}
			else
			{
				putimage(flowerArray.x, flowerArray.y, 30, 25, game1 + 1, 77, 222, SRCAND);	//
				putimage(flowerArray.x, flowerArray.y, 30, 25, game1 + 0, 77, 222, SRCPAINT);
			}
			break;
		case 1:
			if (flowerArray.shape == 0)
			{
				putimage(flowerArray.x, flowerArray.y, 30, 25, game1 + 1, 77, 259, SRCAND);	//
				putimage(flowerArray.x, flowerArray.y, 30, 25, game1 + 0, 77, 259, SRCPAINT);
			}
			else
			{
				putimage(flowerArray.x, flowerArray.y, 30, 25, game1 + 1, 77, 291, SRCAND);	//
				putimage(flowerArray.x, flowerArray.y, 30, 25, game1 + 0, 77, 291, SRCPAINT);
			}
			break;
		case 2:
			if (flowerArray.shape == 0)
			{
				putimage(flowerArray.x, flowerArray.y, 30, 25, game1 + 1, 77, 327, SRCAND);	//
				putimage(flowerArray.x, flowerArray.y, 30, 25, game1 + 0, 77, 327, SRCPAINT);
			}
			else
			{
				putimage(flowerArray.x, flowerArray.y, 30, 25, game1 + 1, 77, 359, SRCAND);	//
				putimage(flowerArray.x, flowerArray.y, 30, 25, game1 + 0, 77, 359, SRCPAINT);
			}
			break;

		}
		break;

	}
	

}

//ײ����
int hitFlower(struct Flower flowerArray1[], struct Flower flowerArray2[])
{
	for (int i = 0; i < 3; i++)
	{
	
		
		if (flowerArray1[i].keyApper == 'y')
		{
			if (( (flowerArray1[i].x <= flayBird.x  && flowerArray1[i].x + 30 >= flayBird.x)
				|| (flowerArray1[i].x <= flayBird.x+34 && flowerArray1[i].x + 30 >= flayBird.x+34))
				&& (  flowerArray1[i].y+25>= flayBird.y)  )
			{
				return 1;
			}
			
		}
		if (flowerArray2[i].keyApper == 'y')
		{
			if (((flowerArray2[i].x <= flayBird.x  && flowerArray2[i].x + 30 >= flayBird.x)
				|| (flowerArray2[i].x <= flayBird.x + 34 && flowerArray2[i].x + 30 >= flayBird.x + 34))
				&& (flowerArray2[i].y <= flayBird.y+24))
			{
				return 1;
			}
		}
	}
	return 0;
}