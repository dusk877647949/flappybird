//=========================�Ŀ����=========================//
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <conio.h>	    //�������� _getch()
#include <string.h>		
#include <time.h>		//�����srand��������
#include <graphics.h>	//ͼ�ο��ļ�
#include <mmsystem.h>	//���ֲ���
#include "function.h"   //�����Զ���ͷ�ļ�
#include "mysql.h"
#include "IMAGE.h"
#include "StructAndGlobal.h"
#pragma comment(lib,"winmm.lib")
#pragma comment(lib,"libmysql.lib")

//=========================��������========================//

//���ڹ�
void drawTortoise()
{
	switch (tortoiseStruct.shape)
	{
	case 0:
		putimage(tortoiseStruct.x, tortoiseStruct.y-9, 33, 40, game3 + 1, 24, 244, SRCAND);	//�ڹ�
		putimage(tortoiseStruct.x, tortoiseStruct.y-9, 33, 40, game3 + 0, 24, 244, SRCPAINT);
		break;
	case 1:
		putimage(tortoiseStruct.x, tortoiseStruct.y, 40, 31, game3 + 1, 70, 253, SRCAND);	//�ڹ�
		putimage(tortoiseStruct.x, tortoiseStruct.y, 40, 31, game3 + 0, 70, 253, SRCPAINT);
		break;
	case 2:
		putimage(tortoiseStruct.x, tortoiseStruct.y, 34, 39, game3 + 1, 114, 253, SRCAND);	//�ڹ�
		putimage(tortoiseStruct.x, tortoiseStruct.y, 34, 39, game3 + 0, 114, 253, SRCPAINT);
		break;
	case 3:
		putimage(tortoiseStruct.x, tortoiseStruct.y, 38, 31, game3 + 1, 162, 253, SRCAND);	//�ڹ�
		putimage(tortoiseStruct.x, tortoiseStruct.y, 38, 31, game3 + 0, 162, 253, SRCPAINT);
		break;
	case 4:
		putimage(tortoiseStruct.x, tortoiseStruct.y, 38, 29, game3 + 1, 212, 253, SRCAND);	//�ڹ�
		putimage(tortoiseStruct.x, tortoiseStruct.y, 38, 29, game3 + 0, 212, 253, SRCPAINT);
		break;
	case 5:
		putimage(tortoiseStruct.x, tortoiseStruct.y-6, 36, 36, game3 + 1, 262, 247, SRCAND);	//�ڹ�
		putimage(tortoiseStruct.x, tortoiseStruct.y-6, 36, 36, game3 + 0, 262, 247, SRCPAINT);
		break;

	}
	tortoiseStruct.shape++;
	if (tortoiseStruct.shape == 6)
	{
		tortoiseStruct.shape = 0;
	}



}


//�ж��Ƿ�ײ���ڹ�
int  hitTortoise()
{
	int key = tortoiseStruct.shape-1;
	if (key == 0)
	{
		key = 5;
	}
	switch (key)
	{
	case 0:
		if ( ((tortoiseStruct.x <= flayBird.x  && flayBird.x <= tortoiseStruct.x + 33) ||
			(tortoiseStruct.x <= flayBird.x + 34 &&  flayBird.x + 34 <= tortoiseStruct.x + 33 )) &&
			(( tortoiseStruct.y -9 <= flayBird.y && flayBird.y <= tortoiseStruct.y-9+40  ) ||
			(tortoiseStruct.y -9 <= flayBird.y + 24 && flayBird.y + 24 <= tortoiseStruct.y-9+40  ))  )
		{
			return 1;
		}
		else
		{
			return 0;
		}
		break;
	case 1:
		if ( ((tortoiseStruct.x <= flayBird.x  && flayBird.x <= tortoiseStruct.x + 31) ||
			(tortoiseStruct.x <= flayBird.x + 34 && flayBird.x + 34 <= tortoiseStruct.x + 31)) &&
			((tortoiseStruct.y  <= flayBird.y && flayBird.y <= tortoiseStruct.y  + 31) ||
			(tortoiseStruct.y  <= flayBird.y + 24 && flayBird.y + 24 <= tortoiseStruct.y  + 31))  )
		{
			return 1;
		}
		else
		{
			return 0;
		}
		break;
	case 2:
		if (((tortoiseStruct.x <= flayBird.x  && flayBird.x <= tortoiseStruct.x + 34) ||
			(tortoiseStruct.x <= flayBird.x + 34 && flayBird.x + 34 <= tortoiseStruct.x + 34)) &&
			((tortoiseStruct.y <= flayBird.y && flayBird.y <= tortoiseStruct.y + 39) ||
			(tortoiseStruct.y <= flayBird.y + 24 && flayBird.y + 24 <= tortoiseStruct.y + 39)))
		{
			return 1;
		}
		else
		{
			return 0;
		}
		break;
	case 3:
		if (((tortoiseStruct.x <= flayBird.x  && flayBird.x <= tortoiseStruct.x + 38) ||
			(tortoiseStruct.x <= flayBird.x + 34 && flayBird.x + 34 <= tortoiseStruct.x + 38)) &&
			((tortoiseStruct.y <= flayBird.y && flayBird.y <= tortoiseStruct.y + 31) ||
			(tortoiseStruct.y <= flayBird.y + 24 && flayBird.y + 24 <= tortoiseStruct.y + 31)))
		{
			return 1;
		}
		else
		{
			return 0;
		}
		break;
	case 4:
		if (((tortoiseStruct.x <= flayBird.x  && flayBird.x <= tortoiseStruct.x + 38) ||
			(tortoiseStruct.x <= flayBird.x + 34 && flayBird.x + 34 <= tortoiseStruct.x + 38)) &&
			((tortoiseStruct.y <= flayBird.y && flayBird.y <= tortoiseStruct.y + 29) ||
			(tortoiseStruct.y <= flayBird.y + 24 && flayBird.y + 24 <= tortoiseStruct.y + 29)))
		{
			return 1;
		}
		else
		{
			return 0;
		}
		break;
	case 5:
		if (((tortoiseStruct.x <= flayBird.x  && flayBird.x <= tortoiseStruct.x + 36) ||
			(tortoiseStruct.x <= flayBird.x + 34 && flayBird.x + 34 <= tortoiseStruct.x + 36)) &&
			((tortoiseStruct.y <= flayBird.y && flayBird.y <= tortoiseStruct.y + 36) ||
			(tortoiseStruct.y <= flayBird.y + 24 && flayBird.y + 24 <= tortoiseStruct.y + 36)))
		{
			return 1;
		}
		else
		{
			return 0;
		}
		break;

	}
	

	return 0;
}