//=========================�Ŀ����=========================//
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <conio.h>	    //�������� _getch()
#include <string.h>		
#include <time.h>		//�����srand��������
#include <graphics.h>	//ͼ�ο��ļ�
#include <mmsystem.h>	//���ֲ���
#include "function.h"   //�����Զ���ͷ�ļ�
#include "mysql.h"
#include "IMAGE.h"
#include "StructAndGlobal.h"
#pragma comment(lib,"winmm.lib")
#pragma comment(lib,"libmysql.lib")

//=========================��������========================//

//���ڹ�
void drawTortoise2()
{
	switch (tortoiseStruct2.shape)
	{
	case 0:
		putimage(tortoiseStruct2.x, tortoiseStruct2.y , 23, 32, game3 + 1, 68, 169, SRCAND);	//�ڹ�
		putimage(tortoiseStruct2.x, tortoiseStruct2.y , 23, 32, game3 + 0, 68, 169, SRCPAINT);
		break;
	case 1:
		putimage(tortoiseStruct2.x, tortoiseStruct2.y, 23, 32, game3 + 1, 98, 169, SRCAND);	//�ڹ�
		putimage(tortoiseStruct2.x, tortoiseStruct2.y, 23, 32, game3 + 0, 98, 169, SRCPAINT);
		break;
	case 2:
		putimage(tortoiseStruct2.x, tortoiseStruct2.y, 23, 32, game3 + 1, 128, 169, SRCAND);	//�ڹ�
		putimage(tortoiseStruct2.x, tortoiseStruct2.y, 23, 32, game3 + 0, 128, 169, SRCPAINT);
		break;
	case 3:
		putimage(tortoiseStruct2.x, tortoiseStruct2.y, 23, 32, game3 + 1, 158, 169, SRCAND);	//�ڹ�
		putimage(tortoiseStruct2.x, tortoiseStruct2.y, 23, 32, game3 + 0, 158, 169, SRCPAINT);
		break;
	case 4:
		putimage(tortoiseStruct2.x, tortoiseStruct2.y, 23, 32, game3 + 1, 188, 169, SRCAND);	//�ڹ�
		putimage(tortoiseStruct2.x, tortoiseStruct2.y, 23, 32, game3 + 0, 188, 169, SRCPAINT);
		break;
	case 5:
		putimage(tortoiseStruct2.x, tortoiseStruct2.y, 23, 32, game3 + 1, 218, 169, SRCAND);	//�ڹ�
		putimage(tortoiseStruct2.x, tortoiseStruct2.y, 23, 32, game3 + 0, 218, 169, SRCPAINT);
		break;
	case 6:
		putimage(tortoiseStruct2.x, tortoiseStruct2.y, 23, 32, game3 + 1, 248, 169, SRCAND);	//�ڹ�
		putimage(tortoiseStruct2.x, tortoiseStruct2.y, 23, 32, game3 + 0, 248, 169, SRCPAINT);
		break;
	case 7:
		putimage(tortoiseStruct2.x, tortoiseStruct2.y, 23, 32, game3 + 1, 278, 169, SRCAND);	//�ڹ�
		putimage(tortoiseStruct2.x, tortoiseStruct2.y, 23, 32, game3 + 0, 278, 169, SRCPAINT);
		break;

	}
	tortoiseStruct2.shape++;
	if (tortoiseStruct2.shape == 8)
	{
		tortoiseStruct2.shape = 0;
	}



}


//�ж�ײ������
int hitTortoise2()
{
	if (tortoiseStruct2.key == 1)
	{
		if (((tortoiseStruct2.x <= flayBird.x  && flayBird.x <= tortoiseStruct2.x + 23) ||
			(tortoiseStruct2.x <= flayBird.x + 34 && flayBird.x + 34 <= tortoiseStruct2.x + 23)) &&
			((tortoiseStruct2.y <= flayBird.y && flayBird.y <= tortoiseStruct2.y + 32) ||
			(tortoiseStruct2.y <= flayBird.y + 32 && flayBird.y + 24 <= tortoiseStruct2.y + 32)))
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	else
	{
		return 0;
	}

}