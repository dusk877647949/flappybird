//=========================�Ŀ����=========================//
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <conio.h>	    //�������� _getch()
#include <string.h>		
#include <time.h>		//�����srand��������
#include <graphics.h>	//ͼ�ο��ļ�
#include <mmsystem.h>	//���ֲ���
#include "function.h"   //�����Զ���ͷ�ļ�
#include "mysql.h"
#include "IMAGE.h"
#include "StructAndGlobal.h"
#pragma comment(lib,"winmm.lib")
#pragma comment(lib,"libmysql.lib")

//=========================��������========================//


 
//�����
void drawSwan()
{
	switch (swanStruct.shape)
	{
	case 0:
		putimage(swanStruct.x, swanStruct.y, 42, 37, game5 + 1, 186, 122, SRCAND);	//
		putimage(swanStruct.x, swanStruct.y, 42, 37, game5 + 0, 186, 122, SRCPAINT);
		swanStruct.y -=5;
		break;
	case 1:
		putimage(swanStruct.x, swanStruct.y, 46, 25, game5 + 1, 183, 94, SRCAND);	//
		putimage(swanStruct.x, swanStruct.y, 46, 25, game5 + 0, 183, 94, SRCPAINT);
		swanStruct.y += 5;
		break;
	 }

	swanStruct.shape++;
	if (swanStruct.shape == 2)
	{
		swanStruct.shape = 0;
	}


}

//�ж�ײ������
int hitSwan()
{
	if (swanStruct.key == 1)
	{
		switch (swanStruct.shape)
		{
		case 0:
			if (((swanStruct.x <= flayBird.x  && flayBird.x <= swanStruct.x + 42) ||
				(swanStruct.x <= flayBird.x + 34 && flayBird.x + 34 <= swanStruct.x + 42)) &&
				((swanStruct.y <= flayBird.y && flayBird.y <= swanStruct.y + 37) ||
				(swanStruct.y <= flayBird.y + 24 && flayBird.y + 24 <= swanStruct.y + 37)))
			{
				return 1;
			}
			else
			{
				return 0;
			}
			break;
		case 1:
			if (((swanStruct.x <= flayBird.x  && flayBird.x <= swanStruct.x + 46) ||
				(swanStruct.x <= flayBird.x + 34 && flayBird.x + 34 <= swanStruct.x + 46)) &&
				((swanStruct.y <= flayBird.y && flayBird.y <= swanStruct.y + 25) ||
				(swanStruct.y <= flayBird.y + 24 && flayBird.y + 24 <= swanStruct.y + 25)))
			{
				return 1;
			}
			else
			{
				return 0;
			}
			break;
		}
				
	}
	else
	{
		return 0;
	}
	return 0;
}