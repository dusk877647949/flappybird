//=========================�Ŀ����=========================//
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <conio.h>	    //�������� _getch()
#include <string.h>		
#include <time.h>		//�����srand��������
#include <graphics.h>	//ͼ�ο��ļ�
#include <mmsystem.h>	//���ֲ���
#include "function.h"   //�����Զ���ͷ�ļ�
#include "mysql.h"
#include "IMAGE.h"
#include "StructAndGlobal.h"
#pragma comment(lib,"winmm.lib")
#pragma comment(lib,"libmysql.lib")

//=========================��������========================//

 
//���ƶ��İ���
void drawLove()
{
	switch (loveStruct.direction)
	{
	case 'w':

		switch (loveStruct.shape)
		{
		case 0:
			putimage(loveStruct.x, loveStruct.y, 42, 16, game5 + 1, 5, 426, SRCAND);	//����
			putimage(loveStruct.x, loveStruct.y, 42, 16, game5 + 0, 5, 426, SRCPAINT);
			break;
		case 1:
			putimage(loveStruct.x, loveStruct.y, 34, 19, game5 + 1, 47, 426, SRCAND);	//����
			putimage(loveStruct.x, loveStruct.y, 34, 19, game5 + 0, 47, 426, SRCPAINT);
			break;

		}
		break;
	case 's':
		switch (loveStruct.shape)
		{
		case 0:
			putimage(loveStruct.x, loveStruct.y, 32, 21, game5 + 1, 84, 420, SRCAND);	//����
			putimage(loveStruct.x, loveStruct.y, 32, 21, game5 + 0, 84, 420, SRCPAINT);
			break;
		case 1:
			putimage(loveStruct.x, loveStruct.y, 36, 17, game5 + 1, 80, 448, SRCAND);	//����
			putimage(loveStruct.x, loveStruct.y, 36, 17, game5 + 0, 80, 448, SRCPAINT);
			break;
		 

		}
		break;
	}

	loveStruct.shape++;
	if (loveStruct.shape == 2)
	{
		loveStruct.shape = 0;
	}


}

//�ж�ײ������
int hitLove()
{
	switch (loveStruct.direction)
	{
	case 'w':

		switch (loveStruct.shape)
		{
		case 0:
			if (loveStruct.key == 1)	//���ж��Ƿ��а���
			{
				if (((loveStruct.x <= flayBird.x  && flayBird.x <= loveStruct.x + 42) ||
					(loveStruct.x <= flayBird.x + 34 && flayBird.x + 34 <= loveStruct.x + 42)) &&
					((loveStruct.y <= flayBird.y && flayBird.y <= loveStruct.y + 16) ||
					(loveStruct.y <= flayBird.y + 24 && flayBird.y + 24 <= loveStruct.y + 16)))
				{
					return 1;
				}
				else
				{
					return 0;
				}
			}
			break;
		case 1:
			if (loveStruct.key == 1)//���ж��Ƿ��а���
			{
				//�ж��Ƿ���С��ķ�Χ��
				if (((loveStruct.x <= flayBird.x  && flayBird.x <= loveStruct.x + 34) ||
					(loveStruct.x <= flayBird.x + 34 && flayBird.x + 34 <= loveStruct.x + 34)) &&
					((loveStruct.y <= flayBird.y && flayBird.y <= loveStruct.y + 19) ||
					(loveStruct.y <= flayBird.y + 24 && flayBird.y + 24 <= loveStruct.y + 19)))
				{
					return 1;
				}
				else
				{
					return 0;
				}
			}
			break;

		}
		break;
	case 's':
		switch (loveStruct.shape)
		{
		case 0:
			if (loveStruct.key == 1)//���ж��Ƿ��а���
			{
				//�ж��Ƿ���С��ķ�Χ��
				if (((loveStruct.x <= flayBird.x  && flayBird.x <= loveStruct.x + 32) ||
					(loveStruct.x <= flayBird.x + 34 && flayBird.x + 34 <= loveStruct.x + 32)) &&
					((loveStruct.y <= flayBird.y && flayBird.y <= loveStruct.y + 21) ||
					(loveStruct.y <= flayBird.y + 24 && flayBird.y + 24 <= loveStruct.y + 21)))
				{
					return 1;
				}
				else
				{
					return 0;
				}
			}
			break;
		case 1:
			if (loveStruct.key == 1)//���ж��Ƿ��а���
			{
				//�ж��Ƿ���С��ķ�Χ��
				if (((loveStruct.x <= flayBird.x  && flayBird.x <= loveStruct.x + 36) ||
					(loveStruct.x <= flayBird.x + 34 && flayBird.x + 34 <= loveStruct.x + 36)) &&
					((loveStruct.y <= flayBird.y && flayBird.y <= loveStruct.y + 17) ||
					(loveStruct.y <= flayBird.y + 24 && flayBird.y + 24 <= loveStruct.y + 17)))
				{
					return 1;
				}
				else
				{
					return 0;
				}
			}
			break;


		}
		break;
	}

	return 0;	//�������ϣ�����0
}